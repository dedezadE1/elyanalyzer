const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://hijremakugwwjrgugsrb.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpanJlbWFrdWd3d2pyZ3Vnc3JiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5NjM5MDEsImV4cCI6MjA2NjUzOTkwMX0.vWerzW7XaAimP3Ew8PRVeH67FbyXk3RAYxJAm75PQzY'
);

async function checkSchema() {
  console.log('=== Category Scores Tablosu Yapısı ===');
  
  // Test query to see what columns exist
  const { data, error } = await supabase
    .from('category_scores')
    .select('*')
    .limit(1);
  
  if (error) {
    console.error('Hata:', error);
  } else {
    console.log('Mevcut kolonlar:', data && data.length > 0 ? Object.keys(data[0]) : 'Veri yok');
  }
  
  // Try to insert a test record to see what's missing
  console.log('\n=== Test Insert ===');
  const testData = {
    scan_id: '00000000-0000-0000-0000-000000000001',
    category_id: '11111111-1111-1111-1111-111111111111',
    score: 85,
    critical_issues: 2,
    warning_issues: 3,
    info_issues: 5
  };
  
  const { data: insertData, error: insertError } = await supabase
    .from('category_scores')
    .insert(testData)
    .select();
  
  if (insertError) {
    console.error('Insert hatası:', insertError);
  } else {
    console.log('Insert başarılı:', insertData);
  }
}

checkSchema().catch(console.error); 