package main

import (
	"os"
)

type Config struct {
	SupabaseURL        string
	SupabaseAnonKey    string
	SupabaseServiceKey string
	Port               string
	Environment        string
	AllowedOrigins     []string
	JWTSecret          string
}

func LoadConfig() *Config {
	return &Config{
		SupabaseURL:        getEnv("SUPABASE_URL", "https://hijremakugwwjrgugsrb.supabase.co"),
		SupabaseAnonKey:    getEnv("SUPABASE_ANON_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpanJlbWFrdWd3d2pyZ3Vnc3JiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5NjM5MDEsImV4cCI6MjA2NjUzOTkwMX0.vWerzW7XaAimP3Ew8PRVeH67FbyXk3RAYxJAm75PQzY"),
		SupabaseServiceKey: getEnv("SUPABASE_SERVICE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpanJlbWFrdWd3d2pyZ3Vnc3JiIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MDk2MzkwMSwiZXhwIjoyMDY2NTM5OTAxfQ.uHKDBP2hZU7zIIQN-aRnT52lzSVk35Tfx7vjsyk9Sng"),
		Port:               getEnv("PORT", "8080"),
		Environment:        getEnv("ENVIRONMENT", "development"),
		AllowedOrigins:     getEnvSlice("ALLOWED_ORIGINS", []string{"http://localhost:3000", "http://localhost:1420"}),
		JWTSecret:          getEnv("JWT_SECRET", "your-secret-key-change-in-production"),
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvSlice(key string, defaultValue []string) []string {
	if value := os.Getenv(key); value != "" {
		// Split by comma for multiple origins
		return []string{value} // Simplified for now
	}
	return defaultValue
}
