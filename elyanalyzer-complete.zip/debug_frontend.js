const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://hijremakugwwjrgugsrb.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpanJlbWFrdWd3d2pyZ3Vnc3JiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5NjM5MDEsImV4cCI6MjA2NjUzOTkwMX0.vWerzW7XaAimP3Ew8PRVeH67FbyXk3RAYxJAm75PQzY'
);

async function debugFrontend() {
  console.log('🔍 Frontend Debug - Son Scan ID');
  
  // Son scan'i bul
  const { data: scans, error: scanError } = await supabase
    .from('analysis_scans')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(1);
  
  if (scanError) {
    console.error('❌ Scan hatası:', scanError);
    return;
  }
  
  console.log('📊 Son scan:', scans?.[0]);
  
  if (!scans || scans.length === 0) {
    console.log('❌ Hiç scan bulunamadı');
    return;
  }
  
  const scanId = scans[0].id;
  console.log('🔍 Scan ID:', scanId);
  
  // Bu scan'e ait category scores'ları getir
  console.log('\n🎯 Category Scores:');
  const { data: scores, error: scoresError } = await supabase
    .from('category_scores')
    .select(`
      *,
      analysis_categories (
        name,
        display_name,
        icon
      )
    `)
    .eq('scan_id', scanId)
    .order('created_at', { ascending: false });
  
  if (scoresError) {
    console.error('❌ Scores hatası:', scoresError);
    return;
  }
  
  console.log(`📊 ${scores?.length || 0} kategori skoru bulundu:`);
  scores?.forEach((score, i) => {
    console.log(`  ${i+1}. ${score.analysis_categories?.name}: score=${score.score}, critical=${score.critical_issues}, warning=${score.warning_issues}, info=${score.info_issues}`);
  });
  
  // Frontend'in kullandığı sorguyu test et
  console.log('\n🧪 Frontend Query Test:');
  const { data: testData, error: testError } = await supabase
    .from('analysis_categories')
    .select('*')
    .order('name');
  
  if (testError) {
    console.error('❌ Test hatası:', testError);
  } else {
    console.log(`📊 ${testData?.length || 0} kategori bulundu`);
  }
  
  const { data: scoresData, error: scoresDataError } = await supabase
    .from('category_scores')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (scoresDataError) {
    console.error('❌ Scores data hatası:', scoresDataError);
  } else {
    console.log(`📊 ${scoresData?.length || 0} score kaydı bulundu`);
    
    // En son 5 skoru göster
    console.log('\n📈 Son 5 Score:');
    scoresData?.slice(0, 5).forEach((score, i) => {
      console.log(`  ${i+1}. Category: ${score.category_id}, Score: ${score.score}, Critical: ${score.critical_issues}, Warning: ${score.warning_issues}, Info: ${score.info_issues}`);
    });
  }
}

debugFrontend().catch(console.error); 