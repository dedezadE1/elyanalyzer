const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://lqtqwqnfxqxlzqfcqbio.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxxdHF3cW5meHF4bHpxZmNxYmlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU0ODY2NjcsImV4cCI6MjA1MTA2MjY2N30.QlvKj2XLNJAEqtFfXmrxHKLWK5w_vhgZTGVjOJRLYnQ'
);

async function checkCategories() {
  console.log('=== Kategoriler ===');
  const { data: categories, error: catError } = await supabase
    .from('analysis_categories')
    .select('*')
    .order('name');
  
  if (catError) {
    console.error('Kategori hatası:', catError);
  } else {
    console.log('Toplam kategori sayısı:', categories?.length || 0);
    categories?.forEach(cat => {
      console.log(`- ${cat.name} (${cat.display_name}) - ${cat.icon}`);
    });
  }
  
  console.log('\n=== Son Skorlar ===');
  const { data: scores, error: scoreError } = await supabase
    .from('category_scores')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(20);
    
  if (scoreError) {
    console.error('Skor hatası:', scoreError);
  } else {
    console.log('Toplam skor sayısı:', scores?.length || 0);
    scores?.slice(0, 5).forEach(score => {
      console.log(`- Kategori: ${score.category_id}, Skor: ${score.score}, Critical: ${score.critical_issues}, Warning: ${score.warning_issues}, Info: ${score.info_issues}`);
    });
  }
}

checkCategories().then(() => process.exit(0)).catch(err => { console.error(err); process.exit(1); }); 