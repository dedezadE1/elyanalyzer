import { createClient } from '@supabase/supabase-js'

// Supabase project configuration from environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env file.')
}

// Validate required environment variables
if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing required Supabase environment variables. Please check VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.')
}

export const supabase = createClient(supabaseUrl, supabaseKey)

// Types for our database
export interface User {
  id: string
  email: string
  name: string
  created_at: string
}

export interface Project {
  id: string
  user_id: string
  name: string
  path: string
  created_at: string
}

export interface AnalysisResult {
  id: string
  project_id: string
  issues_found: number
  critical_issues: number
  scan_data: any
  created_at: string
}

// Auth helper functions
export const authHelpers = {
  isAdmin: async () => {
    const { data: { user } } = await supabase.auth.getUser()
    return user?.user_metadata?.role === 'admin'
  },

  getCurrentUserRole: async () => {
    const { data: { user } } = await supabase.auth.getUser()
    return user?.user_metadata?.role || 'user'
  },
  
  signUp: async (email: string, password: string, name: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name
        }
      }
    })
    return { data, error }
  },

  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  },

  // GitHub OAuth giriş
  signInWithGitHub: async () => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'github',
      options: {
        redirectTo: `${window.location.origin}/dashboard`,
        scopes: 'read:user user:email'
      }
    })
    return { data, error }
  },

  signOut: async () => {
    const { error } = await supabase.auth.signOut()
    return { error }
  },

  getCurrentUser: () => {
    return supabase.auth.getUser()
  }
} 