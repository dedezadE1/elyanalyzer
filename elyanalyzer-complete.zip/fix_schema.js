const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://hijremakugwwjrgugsrb.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpanJlbWFrdWd3d2pyZ3Vnc3JiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTA5NjM5MDEsImV4cCI6MjA2NjUzOTkwMX0.vWerzW7XaAimP3Ew8PRVeH67FbyXk3RAYxJAm75PQzY'
);

async function fixSchema() {
  console.log('🔧 Eksik warning_issues kolonunu ekliyoruz...');
  
  // SQL to add missing column
  const { data, error } = await supabase.rpc('exec_sql', {
    sql: 'ALTER TABLE category_scores ADD COLUMN IF NOT EXISTS warning_issues INTEGER DEFAULT 0;'
  });
  
  if (error) {
    console.error('❌ SQL hatası:', error);
    console.log('ℹ️  Manuel olarak Supabase SQL Editor\'da şu komutu çalıştırın:');
    console.log('ALTER TABLE category_scores ADD COLUMN warning_issues INTEGER DEFAULT 0;');
  } else {
    console.log('✅ warning_issues kolonu eklendi!');
  }
  
  // Test the fix
  console.log('\n🧪 Test ediyoruz...');
  const testData = {
    scan_id: '39c0ca3c-d01e-4cf4-92df-183a5c1ef4a0', // Gerçek scan ID
    category_id: '11111111-1111-1111-1111-111111111111',
    score: 85,
    critical_issues: 2,
    warning_issues: 3,
    info_issues: 5
  };
  
  const { data: insertData, error: insertError } = await supabase
    .from('category_scores')
    .insert(testData)
    .select();
  
  if (insertError) {
    console.error('❌ Test insert hatası:', insertError);
  } else {
    console.log('✅ Test insert başarılı:', insertData);
  }
}

fixSchema().catch(console.error); 